import React from "react";

const Component = ({ number }) => {
  return (
    <div>
      <h1>I am Component {number}</h1>
    </div>
  );
};

export default Component;
